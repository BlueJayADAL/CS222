// In the nano editor,
// Use Ctrl+o to save the file
// Use Ctrl+x to exit the file

#include <stdio.h>

int main(void) {
    // FIX THE ERROR IN THIS MAIN() FUNCTION
    printf("I love ", "Systems Programming!");
    return 0;
}

