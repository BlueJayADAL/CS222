/*************************************************
   CS 222 System Programming
   P. Li
   Source file for demo: Dynamic memory allocation
   and data structures

   Contains main function for command line parsing
**************************************************/
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "LLnode.h"

// String Macro
#define HELP_MANUAL "Usage: program [-a NUM | -p | -f NUM | -d NUM]\n"

// readCmd() helper function prototype
char *readCmd();

int main (int argc, char ** argv) {
    LLnode *mylist = NULL;   // Node pointer to start of linked list
    LLnode *targetNode;      // Used when finding nodes
    char *cmd = NULL;	     // Input string command
    int inVal;               // Input value to be added/found/deleted
    char junk;               // Used to hold junk characters 

    // command line parsing
    


    // Loop to check and execute the user's command
    //   Only breaks out when receives "exit"
    do {
        // Prompt user to enter a string command
        printf("\nEnter command: ");
        // Read string from standard input with readCmd() function
        cmd = readCmd();

        // Add integer to list
        if (strcmp(cmd, "add") == 0) {
            printf("Enter number to be added: ");
            // The space before %d tries to match junks 
            // from last input line, such as ENTER
            scanf(" %d", &inVal); 



        }

        // Delete node from list
        else if (strcmp(cmd, "delete") == 0) {
            printf("Enter number to be deleted: ");
            scanf(" %d", &inVal); 



        }

        // Find node in list
        else if (strcmp(cmd, "find") == 0) {
            printf("Enter number to be found: ");
            scanf(" %d", &inVal); 
 
 


        }

        // Print contents of entire list
        else if (strcmp(cmd, "print") == 0) {



        }
        // Invalid command
        else if (strcmp(cmd, "exit") != 0) {


        }
    } while (strcmp(cmd, "exit") != 0);
    return 0;
}

// Reads string from standard input and dynamically allocates space
// Assumes user input string terminates with '\n' (ENTER)
char *readCmd() {

    return NULL;
}
