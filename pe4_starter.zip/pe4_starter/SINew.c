//
//  SINew.c
//  PE4_structures
//


#include "SINew.h"
#include <stdio.h>
#include <string.h>

// Print information about student
void printStudent(SINew *s) {
    // FUNCTION CURRENTLY DOES NOTHING
}

// Reads student information into existing structure
void readStudent(SINew *s) {
    // FUNCTION CURRENTLY DOES NOTHING
}

// Print list of students
void printList(SINew list[], int n) {
    // FUNCTION CURRENTLY DOES NOTHING
}

// Find student in list, based on last name
// Returns index if student found, -1 otherwise
int findByLName(SINew list[], int n, char lname[]) {
    // FUNCTION CURRENTLY DOES NOTHING
    return -1;
}

// Find student in list, based on ID #
// Returns index if student found, -1 otherwise
int findByID(SINew list[], int n, unsigned int sID) {
    // FUNCTION CURRENTLY DOES NOTHING
    return -1;
}
