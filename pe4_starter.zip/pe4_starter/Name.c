//
//  Name.c
//  PE4_structures
//


#include "Name.h"
#include <stdio.h>

// Print contents of Name struct
void printName(Name *n) {
	// FUNCTION CURRENTLY DOES NOTHING
}

// Read information into existing Name
void readName(Name *n) {
	// FUNCTION CURRENTLY DOES NOTHING
}
