//
//  Name.h
//  PE4_structures
//


#ifndef NAME_H
#define NAME_H

typedef struct {
    char first[50];
    char middle;
    char last[50];
} Name;

// Print contents of Name struct
void printName(Name *n);

// Read information into existing Name
void readName(Name *n);

#endif /* NAME_H */
