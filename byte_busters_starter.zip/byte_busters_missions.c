/*
 * Byte Busters Missions
 * This file contains the implementations for various missions.
 * Each mission is a separate function that demonstrates different file I/O operations.
 * The missions are:
 * 1. Simple logger using fprintf and fscanf
 * 2. Book reader using fread and fwrite
 * 3. Echo twist using getchar, putchar, and ungetc
 * 4. File filter using fgets and fputs
 */
#include <stdio.h>
#include <string.h>
#include <time.h>

// Mission 1: fprintf and fscanf
void mission1_logger() {
    // TODO: Implement a simple logger
}

// Mission 2: fread and fwrite
void mission2_book_reader() {
    // TODO: Implement a book reader
}

// Mission 3: getchar, putchar, ungetc
void mission3_echo_twist() {
    // TODO: Implement an echo twist
}

// Mission 4: fgets and fputs
void mission4_file_filter() {
    // TODO: Implement a file filter
}

int main() {
    int choice;
    printf("Choose a mission (1-4): ");
    scanf("%d", &choice);
    getchar(); // consume leftover newline

    switch (choice) {
        case 1:
            mission1_logger();
            break;
        case 2:
            mission2_book_reader();
            break;
        case 3:
            mission3_echo_twist();
            break;
        case 4:
            mission4_file_filter();
            break;
        default:
            printf("Invalid mission number.\n");
    }

    return 0;
}
