#include <stdio.h>
#include "pointer_functions.h"

/*
 Given two integer arguments, x and y, 
 store the quotient and remainder of x / y 
 into locations specified by arguments 
 q and r, respectively.
*/
void divQR(int x, int y, int *q, int *r) {

}

/*
 Swap the values of two double-precision 
 variables a and b. 
*/
void swap(double *a, double *b) {

}

/*
 This is a function that takes a pointer to a char.
 If the char is an upper case letter, we change it 
 to lower case; otherwise, we do nothing
 Remember that most char values are not letters!
*/
void makeLower(char* letter) {

}