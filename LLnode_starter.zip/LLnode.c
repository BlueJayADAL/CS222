/*****************************************************
    EGR/CS 222 System Programming
    P. Li
    Source file for demo: Dynamic memory allocation
    and data structures

    Contains function definitions for functions
    prototyped in LLnode.h
******************************************************/

#include <stdlib.h>
#include <stdio.h>
#include "LLnode.h"

// Add integer to list and return list's starting address
LLnode *addNode(LLnode *list, int v) {



    // Allocate space for a new node; exit if error
    
    


    // Copy value to new node
    
    

    // Next points to old beginning of list
    
    
}

// Find node in list and return pointer
//   (or NULL if not found)
LLnode *findNode(LLnode *list, int v) {
    // Create pointer to start of list
    
    

    // Loop to visit all nodes in list
    while (              ) {
        // For current node:
        //   a. Check if data you want is in that node --> return address if so
        
        

        //   b. Otherwise, move to the next node
        
        

    }

    // If data isn't found, return NULL
    return NULL;
}

// Delete node from list (if present)
// Return starting address of list when done
LLnode *delNode(LLnode *list, int v) {
    // Variable declaration
    
    // Loop to find the proper place matching v
    
    

    // 1. Went through entire list but no match -- return the original
    if (        ) {

    }
    
    // 2. Match found (v == cur->value), so delete cur node
    else {
        // a. Match found in first node
        
        

        // b. Match found outside of first node
        
        

        // Free the space for either case a or b. 
        
        
    }
}

// Print contents of entire list
void printList(LLnode *list) {
    // Create pointer to start of list
    LLnode *n = list;

    // List is empty
    
    

    // List not empty, then print
    
    


}

// Frees entire list before end of program to avoid memory leaks
void freeList(LLnode *list) {
    
    
    
}
