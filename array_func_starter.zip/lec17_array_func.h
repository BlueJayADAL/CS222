#ifndef lec17_array_func_h
#define lec17_array_func_h

/*** Function Prototypes ***/
void printArray(double arr[], int n);
double findAvg(double arr[], int n);
double findMax(double arr[], int n);
void sclAry(double tests[], int n, int s);

#endif