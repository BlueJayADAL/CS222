# Welcome!

This is a game to teach you the basics of using a POSIX (Linux, BSD, UNIX) terminal.

The game is adopted from bashcrawl with slight modifications.

## Try it on your virtual machine

To start playing, open a terminal.

Then use the "cd" command to navigate to the "entrance" directory...

```
$ cd /home/jj/proj1_cmd/entrance
```

Your first move is very important.
Type this into your terminal:

```
cat scroll
```

You are now playing the game.
May the Blue Jay Spirit save you.

